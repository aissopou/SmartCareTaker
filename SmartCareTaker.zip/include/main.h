//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
#ifndef MAIN_H_
#define MAIN_H_

#define APP_ALS_PERIODIC_INTERVAL_MS    (2000)	/* Measurement Period for Continous mode (inner loop) */

#define APP_ALS_THRESHOLD_LEVEL_LUX     (10)	/* If LUX measured is above this value then an interrupt is generated */

#define APP_ALS_LOOP_INTERVAL_MS        (30000) /* Measurement Period outer loop */

/** \brief Period for starting of environmental measurements in milliseconds. */
#define APP_ENV_MEASUREMENT_PERIOD     (30000)

#define APP_TEMP_LOW     (18.0)
#define APP_TEMP_HIGH     (21.0)

#define APP_HUM_LOW     (70.0)
#define APP_HUM_HIGH     (72.0)


/** \brief Prints measured environmental data to console every time new data
 * are measured.
 */
void PrintEnvData(struct BME680_ENV_Data *data);

void ALS_ReadCallback(uint32_t lux, bool is_interrupt);

#endif /* MAIN_H_ */
