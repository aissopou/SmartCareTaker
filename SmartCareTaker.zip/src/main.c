//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <BDK.h>
#include "BSP_Components.h"

#include "main.h"

int main(void)
{
    int32_t status = 0;

    BDK_Initialize();

    LED_Initialize(LED0);
    LED_Initialize(LED1);
    LED_Initialize(LED2);

    printf("\r\nModified Light Intensity Monitoring App.\r\n");

    status = NOA1305_ALS_Initialize();
    ASSERT_DEBUG(status == 0);

    /* Initialize sensor with preset settings and verify communication. */
       	status = BME680_ENV_Initialize();
       	ASSERT_DEBUG(status == 0);

       	/* Check that measurement period is larger that measurement duration. */
       	ASSERT_DEBUG(APP_ENV_MEASUREMENT_PERIOD > BME680_ENV_GetProfileDuration());

       	/* Start periodic measurements. */
       	    status = BME680_ENV_StartPeriodic(&PrintEnvData,
       	            APP_ENV_MEASUREMENT_PERIOD);
       		ASSERT_DEBUG(status == 0);


   /* START CONTINOUS MEASUREMENTS EVERY 2 secs. (Value set in main.h) */
    status = NOA1305_ALS_StartContinuous(APP_ALS_PERIODIC_INTERVAL_MS,
            &ALS_ReadCallback);
    ASSERT_DEBUG(status == 0);

    status = NOA1305_ALS_EnableInterrupt(APP_ALS_THRESHOLD_LEVEL_LUX); /*Enable Interupts for LUX Values above APP_ALS_THRESHOLD_LEVEL_LUX */
    ASSERT_DEBUG(status == 0);


    uint32_t tt = HAL_Time();

    printf("MAIN LOOP STARTS xxxxxxxxxxxxxxxxxxxx.\r\n");
    while (1)
    {
        /* Execute any events that occurred and refresh Watchdog. */
        BDK_Schedule();

        /* Latest measured light level can be read at any time in continuous
         * mode.
         */
        if (HAL_TIME_ELAPSED_SINCE(tt) > APP_ALS_LOOP_INTERVAL_MS)
        {
            tt = HAL_Time();

            uint32_t lux;
            if (NOA1305_ALS_ReadLux(&lux) == NOA1305_OK)
            {
                if (lux<=APP_ALS_THRESHOLD_LEVEL_LUX) {
            	printf("BOX IS CLOSED ***** LUX = %lu\r\n", lux);
                }
                else {
                	printf("BOX IS OPENED !!!!!!! LUX = %lu\r\n", lux);
                	                }

            }
            else
            {
                printf("Measurement error.\r\n");
            }
        }

        SYS_WAIT_FOR_INTERRUPT;
    }

    return 0;
}


void PrintEnvData(struct BME680_ENV_Data *data)
{
    int32_t tmp;

    /* Print measured data.
     *
     * Note:
     * newlib-nano printf does not support float by default.
     * To enable float in printf enable following option in project properties:
     *   C/C++ Build -> Settings -> GNU ARM Cross Linker -> Miscellaneous
     *   -> Use float with nano printf
     */
    /* printf("ENV: Measurement done [%lu ms]\r\n", HAL_Time()); */
    printf("ENIVORNMENTAL DATA BEGIN---------------------------\n");
    printf("\n");

    tmp = data->temperature / 100;
    if((tmp>APP_TEMP_LOW) & (tmp<APP_TEMP_HIGH)) {
    	printf(" TEMPERATURE WITHIN LIMITS -->  %ld.%02ld �C\r\n", tmp, data->temperature - (tmp * 100));
    }
    else {
    printf(" TEMPERATURE OFF LIMITS !!!!!!  %ld.%02ld �C\r\n", tmp, data->temperature - (tmp * 100));
    }

    tmp = data->humidity / 1000;
    if((tmp>APP_HUM_LOW) & (tmp<APP_HUM_HIGH)) {
        	printf(" HUMIDITY WITHIN LIMITS -->  %ld.%02ld �C\r\n", tmp, data->humidity - (tmp * 100));
        }
        else {
        printf(" HUMIDITY OFF LIMITS !!!!!!  %ld.%02ld �C\r\n", tmp, data->humidity - (tmp * 100));
        }
    printf("ENIVORNMENTAL DATA END---------------------------\n");
    printf("\n");

   /* printf(" pressure=%lu Pa\r\n\n", data->pressure); */
}


void ALS_ReadCallback(uint32_t lux, bool is_interrupt)
{
    if (is_interrupt == true)
    {
        // Print this line if callback was called in response to lux value
        // passing above / below threshold value.
    	if (lux<=APP_ALS_THRESHOLD_LEVEL_LUX) {
                        printf("\n");
    	            	printf("BOX IS CLOSED ***** LUX = %lu\r\n", lux);
    	                }
    	                else {
    	                	printf("\n");
    	                	printf("LUX value passed threshold. BOX WAS OPENED!!! %lu\r\n", lux);
    	                	                }
           }
    // printf("ALS: LUX = %lu\r\n\n", lux);  /* No need to call this all the time. Outer Loop will report Values */
}
